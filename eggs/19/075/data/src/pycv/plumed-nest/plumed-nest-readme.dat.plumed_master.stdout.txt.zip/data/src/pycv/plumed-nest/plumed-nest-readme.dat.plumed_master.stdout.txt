PLUMED: PLUMED is starting
PLUMED: Version: 2.10.0-dev (git: 29babd0c7) compiled on May 22 2024 at 21:30:40
PLUMED: Please cite these papers when using PLUMED [1][2]
PLUMED: For further information see the PLUMED web page at http://www.plumed.org
PLUMED: Root: /home/runner/opt/lib/plumed_master
PLUMED: LibraryPath: /home/runner/opt/lib/libplumed_masterKernel.so
PLUMED: For installed feature, see /home/runner/opt/lib/plumed_master/src/config/config.txt
PLUMED: Molecular dynamics engine: driver
PLUMED: Precision of reals: 8
PLUMED: Running over 1 node
PLUMED: Number of threads: 1
PLUMED: Cache line size: 512
PLUMED: Number of atoms: 100000
PLUMED: File suffix: 
PLUMED: Timestep: 1.000000
PLUMED: KbT: 2.490000
PLUMED: Relevant bibliography:
PLUMED:   [1] The PLUMED consortium, Nat. Methods 16, 670 (2019)
PLUMED:   [2] Tribello, Bonomi, Branduardi, Camilloni, and Bussi, Comput. Phys. Commun. 185, 604 (2014)
PLUMED: Please read and cite where appropriate!
PLUMED: Finished setup
PLUMED: Action ENDPLUMED
PLUMED:   with label @0
PLUMED:                                               Cycles        Total      Average      Minimum      Maximum
PLUMED:                                                    1     0.006239     0.006239     0.006239     0.006239
